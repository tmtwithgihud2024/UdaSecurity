package com.udacity.catpoint.security.service;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyFloat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.udacity.catpoint.image.FakeImageService;
import com.udacity.catpoint.security.data.AlarmStatus;
import com.udacity.catpoint.security.data.ArmingStatus;
import com.udacity.catpoint.security.data.SecurityRepository;
import com.udacity.catpoint.security.data.Sensor;
import com.udacity.catpoint.security.data.SensorType;

@ExtendWith(MockitoExtension.class)
public class SecurityServiceTest {
	@Mock
	SecurityRepository securityRepository;

	@Mock
	FakeImageService imageService;

	private SecurityService securityService;

	@BeforeEach
	void init() {
		securityService = new SecurityService(securityRepository, imageService);
	}

	@Test // test case 1 If alarm is armed and a sensor becomes activated, put the system into pending alarm status.
	void alarmIsArmed_andSensorActivated_changePendingAlarmStatus() {
		when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
		when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);
		securityService.changeSensorActivationStatus(new Sensor("sensor_1", SensorType.DOOR), true);
		verify(securityRepository).setAlarmStatus(AlarmStatus.PENDING_ALARM);
	}

	@Test // test case 2 If alarm is armed and a sensor becomes activated and the system is already pending alarm, set the alarm status to alarm.
	void alarmIsArmed_andSensorActivated_andSystemIsAlreadyPending_changeAlarmStatus() {
		when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
		when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
		securityService.changeSensorActivationStatus(new Sensor("sensor_2", SensorType.DOOR), true);
		verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);

	}

	@Test // test case 3 If pending alarm and all sensors are inactive, return to no alarm state.
	void alarmIsPending_andSensorDeactiva_changeNoAlarmStatus() {
		when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
		Sensor sensor = new Sensor("sensor_3", SensorType.DOOR);
		sensor.setActive(true);
		securityService.changeSensorActivationStatus(sensor, false);
		verify(securityRepository).setAlarmStatus(AlarmStatus.NO_ALARM);
	}

	@Test // test case 4 If alarm is active, change in sensor state should not affect the alarm state.
	void alarmIsActive_changeSensorState_AlarmStatus() {
		when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
		securityService.changeSensorActivationStatus(new Sensor("sensor_4", SensorType.DOOR), true);
		verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);
	}

	@Test // test case 5 If a sensor is activated while already active and the system is in pending state, change it to alarm state.
	void sensorIsActivated_systemIsPending_changeToAlarmState() {
		when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
		securityService.changeSensorActivationStatus(new Sensor("sensor_5", SensorType.DOOR), true);
		verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);
	}

	@Test // test case 6 If a sensor is deactivated while already inactive, make no changes to the alarm state.
	void sensorIsDeactivated_noChangeAlarmState() {
		when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);
		Sensor sensor = new Sensor("sensor_6", SensorType.DOOR);
		sensor.setActive(true);
		securityService.changeSensorActivationStatus(sensor, false);
		verify(securityRepository, never()).setAlarmStatus(AlarmStatus.NO_ALARM);
	}

	@Test // test case 7 If the image service identifies an image containing a cat while the system is armed-home, put the system into alarm status.
	void imageContainACat_systemIsArmedHome_changeToAlarmStatus() {
		when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
		when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
		securityService.processImage(mock(BufferedImage.class));
		verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);
	}

	@Test // test case 8 If the image service identifies an image that does not contain a cat, change the status to no alarm as long as the sensors are not active.
	void imageNotContainACat_sensorsNotActive_changeToNoAlarmStatus() {
		Set<Sensor> sensors = new HashSet<>();
		sensors.add(new Sensor("sensor_8_1", SensorType.DOOR));
		sensors.add(new Sensor("sensor_8_2", SensorType.DOOR));
		when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(false);
		when(securityRepository.getSensors()).thenReturn(sensors);
		securityService.processImage(mock(BufferedImage.class));
		verify(securityRepository).setAlarmStatus(AlarmStatus.NO_ALARM);
	}

	@Test // test case 9 If the system is disarmed, set the status to no alarm.
	void systemDisArmed_changeToNoAlarmStatus() {
		securityService.setArmingStatus(ArmingStatus.DISARMED);
		verify(securityRepository).setAlarmStatus(AlarmStatus.NO_ALARM);
	}

	@Test // test case 10 If the system is armed, reset all sensors to inactive.
	void systemArmed_changeSensorstoInactive() {
		Set<Sensor> sensors = new HashSet<>();
		Sensor sensor1 = new Sensor("sensor_10_1", SensorType.DOOR);
		sensor1.setActive(true);
		Sensor sensor2 = new Sensor("sensor_10_2", SensorType.DOOR);
		sensors.add(sensor1);
		sensors.add(sensor2);
		when(securityRepository.getSensors()).thenReturn(sensors);
		securityService.setArmingStatus(ArmingStatus.ARMED_HOME);
		Set<Sensor> sensorsResult = securityService.getSensors();
		for (Sensor sensor : sensorsResult) {
			assertFalse(sensor.getActive());
		}
	}
	@Test // test case 11 If the system is armed-home while the camera shows a cat, set the alarm status to alarm.
	void systemArmedHome_cameraShowsACat_changeToAlarmStatus() {
		when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
		when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
		securityService.processImage(mock(BufferedImage.class));
		verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);
	}

}
